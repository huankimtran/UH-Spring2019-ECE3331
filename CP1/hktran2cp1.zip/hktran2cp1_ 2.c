/*
    Author  : Huan Kim Tran
    UHID    : 1831696
    Date    : 02/05/2019
    CP      : 1.2
*/
#include <stdio.h>                          /* Include to use scanf and printf */

main()
{
    float acc,distance,time;                /* Declaring the variables*/
                                            /* distance will contain the distance traveled in the specified time (hour) at the inputted acceleration (km/h^2)*/
                                            /* acc will contain the the acceleration (km/h^2)*/
                                            /* time will contain the time in hour the user wants to travel*/
    do{
        printf( "Enter next time: ");       /* Prompting the user to input the time*/
        scanf( "%f", &time); 	            /* Getting the time*/
        if(time <= 0)                       /* Checking if the user wants to terminate the program*/
            break;                          /* Exiting the loop*/
        printf( "Enter next acceleration: "); /*Prompting the user to input the acceleration*/
        scanf( "%f", &acc); 	            /* Getting the acceleration*/
        distance = 0.5*acc*time*time;        /* if the input is valid, compute the distance*/
        printf( "Time = %.5f hours\n", time); /* Printing out time with 5-decimal-place format*/
        printf( "Distance = %.5f kilometers\n\n", distance); /* Printing the computed distance with 5decimal-place format*/
    }while(1);                              /* Making infinite loop*/
    printf( "*** End of Program ***\n" );   /* Prompt the user that the program is ending*/
}
