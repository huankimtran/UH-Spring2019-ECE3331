/*
    Author  : Huan Kim Tran
    UHID    : 1831696
    Date    : 02/05/2019
    CP      : 1.1
*/
#include <stdio.h>                          /* Include to use scanf and printf */

main()
{
    int distance, rate, time;               /* Declaring the variables*/
                                            /* distance will contain the distance traveled in the specified time at the predefine rate (km/h)*/
                                            /* rate will contain the the speed (km/h)*/
                                            /* time will contain the time in hour the user wants to travel*/
    rate = 14;                              /* Setting the rate*/
    do{
        printf( "Enter next time: ");       /* Prompting the user to enter the time */
        scanf( "%d", &time); 	            /* Note: %d denotes integer. ampersand (&) is required before each (non pointer) variable in scanf*/
        if(time <= 0)                       /* Checking if the user wants to terminate the program*/
            break;                          /* Exiting the loop*/
        distance = rate * time;             /* if the input is valid, compute the distance*/
        printf( "Time = %d hours\n", time); /* Printing out time*/
        printf( "Distance = %d kilometers\n\n", distance); /* Printing the computed distance*/
    }while(1);
    printf( "*** End of Program ***\n" );   /* Prompt the user that the program is ending*/
}
